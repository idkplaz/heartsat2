package com.customhearts.listeners;

import com.customhearts.CustomHeartsPlugin;
import com.customhearts.hearts.HeartType;
import com.customhearts.managers.PlayerData;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

public class MoltenHeartListener implements Listener {

    private final CustomHeartsPlugin plugin;
    private static final Map<Material, Material> SMELT = new EnumMap<>(Material.class);

    static {
        SMELT.put(Material.IRON_ORE, Material.IRON_INGOT);
        SMELT.put(Material.DEEPSLATE_IRON_ORE, Material.IRON_INGOT);
        SMELT.put(Material.GOLD_ORE, Material.GOLD_INGOT);
        SMELT.put(Material.DEEPSLATE_GOLD_ORE, Material.GOLD_INGOT);
        SMELT.put(Material.COPPER_ORE, Material.COPPER_INGOT);
        SMELT.put(Material.DEEPSLATE_COPPER_ORE, Material.COPPER_INGOT);
        SMELT.put(Material.ANCIENT_DEBRIS, Material.NETHERITE_SCRAP);
        SMELT.put(Material.COAL_ORE, Material.COAL);
        SMELT.put(Material.DEEPSLATE_COAL_ORE, Material.COAL);
        SMELT.put(Material.DIAMOND_ORE, Material.DIAMOND);
        SMELT.put(Material.DEEPSLATE_DIAMOND_ORE, Material.DIAMOND);
        SMELT.put(Material.EMERALD_ORE, Material.EMERALD);
        SMELT.put(Material.DEEPSLATE_EMERALD_ORE, Material.EMERALD);
        SMELT.put(Material.LAPIS_ORE, Material.LAPIS_LAZULI);
        SMELT.put(Material.DEEPSLATE_LAPIS_ORE, Material.LAPIS_LAZULI);
        SMELT.put(Material.REDSTONE_ORE, Material.REDSTONE);
        SMELT.put(Material.DEEPSLATE_REDSTONE_ORE, Material.REDSTONE);
        SMELT.put(Material.NETHER_GOLD_ORE, Material.GOLD_NUGGET);
        SMELT.put(Material.NETHER_QUARTZ_ORE, Material.QUARTZ);
    }

    public MoltenHeartListener(CustomHeartsPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player p = event.getPlayer();
        Material type = event.getBlock().getType();
        plugin.getUnlockManager().checkBlockMined(p, type.name());

        PlayerData data = plugin.getPlayerDataManager().get(p.getUniqueId());
        if (!data.hasEquipped(HeartType.MOLTEN)) return;
        Material result = SMELT.get(type);
        if (result == null) return;
        event.setDropItems(false);
        p.getInventory().addItem(new ItemStack(result));
    }
}
